using UnityEngine;


[DefaultExecutionOrder(-10)]
public class ArmJointController : MonoBehaviour
{
    public ArmAgent agent;
    public float holdSeconds = 3f;

    public Vector2[] jointRanges;

    public float[] homeTargets;

    [Range(0f, 1f)]
    public float randomScale = 0.35f;

    public bool emitActions = true;

    float[] target;
    float hold;
    bool ready;

    public float[] CurrentTarget => target;

    void Start()
    {
        // TODO
    }

    void FixedUpdate()
    {
        // TODO
    }

    public void ActionFrom(float[] destination)
    {
        // TODO
    }

    public void PlaceTarget(bool home)
    {
        // TODO
    }
}
