using UnityEngine;

// TODO: implement Cartesian IK that produces joint goals for the learned controller
public class IkGoalProvider : MonoBehaviour
{
}
