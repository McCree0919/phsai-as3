using Mujoco;
using UnityEngine;

public class ArmAgent : MonoBehaviour
{
    public int JointCount;
    public int StateSize;
    public int ActionSize;

    public MjActuator gripper;
    public MjBody endEffectorBody;
    public Transform endEffector;
    public MjHingeJoint[] joints;
    public MjActuator[] actuators;

    float[] action;
    float[] state;
    bool ready;

    public float[] CurrentAction => action;
    public bool Ready => ready;

    void Awake()
    {
        // TODO
    }

    void FixedUpdate()
    {
        // TODO
    }

    public void InitializeJointsAndActuators()
    {
        // TODO
    }

    public void SetAction(float[] targets)
    {
        // TODO
    }

    public void ApplyAction()
    {
        // TODO
    }

    public float[] Observe()
    {
        // TODO
        return state;
    }

    public void CopyState(float[] destination)
    {
        // TODO
    }

    private T FindComponent<T>(string name) where T : Component
    {
        // TODO
        return null;
    }
}
