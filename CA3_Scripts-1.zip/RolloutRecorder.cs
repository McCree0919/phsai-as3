using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

public class RolloutRecorder : MonoBehaviour
{
    public ArmAgent agent;
    public ArmJointController controller;
    public int steps = 70000;

    readonly List<float[]> states = new();
    readonly List<float[]> actions = new();
    readonly List<float[]> nextStates = new();

    int n;
    float[] prevS;
    float[] prevA;
    bool saved;

    void Start()
    {
        // TODO
    }

    void FixedUpdate()
    {
        // TODO
    }

    float TrackingError()
    {
        // TODO
        return 0f;
    }

    void Save()
    {
        // TODO
    }
}
