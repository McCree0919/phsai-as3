import json
from pathlib import Path
import time
import cma
import numpy as np
import torch
from torch import nn

ROOT = Path(__file__).resolve().parent / "Data"
STATE = 14
ACTION = 7
FEAT = STATE
N_PARAMS = ACTION * FEAT + ACTION

HOME = np.zeros(ACTION, dtype=np.float32)
JOINT_LO = np.full(ACTION, -np.pi, dtype=np.float32)
JOINT_HI = np.full(ACTION, np.pi, dtype=np.float32)
RANDOM_SCALE = 0.35

VEL_PENALTY = 0.05
ACTION_SMOOTH_PENALTY = 0.1
ACTION_SMOOTH = 0.2
MAX_DELTA = 0.05
HORIZON = 200
EPISODES = 16
CMA_ITERS = 60


def build_dynamics():
    model = None # TODO: fill in the model you used in the train.py file
    path = ROOT / "dynamics.pt"
    if not path.exists():
        raise FileNotFoundError(f"Missing {path}. Run train.py first.")
    model.load_state_dict(torch.load(path, map_location="cpu", weights_only=True))
    model.eval()
    return model


def load_norm():
    path = ROOT / "norm.npz"
    if not path.exists():
        raise FileNotFoundError(f"Missing {path}. Run train.py first.")
    data = np.load(path)
    return data["x_mean"], data["x_std"], data["y_mean"], data["y_std"]


def unpack(theta):
    w = theta[: ACTION * FEAT].reshape(ACTION, FEAT)
    b = theta[ACTION * FEAT :]
    return w, b


def policy(state, goal, w, b):
    # TODO
    pass


@torch.no_grad()
def step_dynamics(model, state, action, x_mean, x_std, y_mean, y_std):
    #TODO: get the next step of the world model
    pass


def sample_goal(rng):
    span = (JOINT_HI - JOINT_LO) * 0.5 * RANDOM_SCALE
    goal = HOME + rng.uniform(-span, span)
    return np.clip(goal, JOINT_LO, JOINT_HI).astype(np.float32)


def smooth_action(prev, raw):
    blended = (1.0 - ACTION_SMOOTH) * prev + ACTION_SMOOTH * raw
    delta = np.clip(blended - prev, -MAX_DELTA, MAX_DELTA)
    return np.clip(prev + delta, JOINT_LO, JOINT_HI).astype(np.float32)


def rollout(model, theta, x_mean, x_std, y_mean, y_std, rng):
    # TODO
    pass


def fitness(theta, model, x_mean, x_std, y_mean, y_std, seed):
    rng = np.random.default_rng(seed)
    returns = []
    for _ in range(EPISODES):
        returns.append(rollout(model, theta, x_mean, x_std, y_mean, y_std, rng))

    return -float(np.mean(returns))


def save_controller(theta):
    w, b = unpack(theta)
    payload = {
        "feature": "q_minus_goal_and_qd",
        "state_size": STATE,
        "action_size": ACTION,
        "W": w.astype(float).reshape(-1).tolist(),
        "b": b.astype(float).tolist(),
        "joint_lo": JOINT_LO.astype(float).tolist(),
        "joint_hi": JOINT_HI.astype(float).tolist(),
        "home": HOME.astype(float).tolist(),
        "vel_penalty": VEL_PENALTY,
        "horizon": HORIZON,
    }
    path = ROOT / "controller.json"
    path.write_text(json.dumps(payload, indent=2) + "\n")
    print(f"wrote {path}")


def main():
    # TODO
    pass


if __name__ == "__main__":
    current_time = time.time()
    main()
    end_time = time.time()
    print(f"Training time: {end_time - current_time} seconds")
